"""T9 OS — A Simondonian AI operating system for life orchestration.

"The starting point is not Task but Tension."
"""

__version__ = "0.3.0"
__author__ = "Hanbeen Moon"
