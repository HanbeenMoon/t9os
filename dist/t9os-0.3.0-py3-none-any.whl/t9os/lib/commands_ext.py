"""
T9 OS Seed — extended command module (split from seed.py to maintain line cap)
cmd_reflect, cmd_consolidate, cmd_watch, cmd_history, cmd_relate,
cmd_digest_index, cmd_legacy, cmd_ingest, cmd_resurface, cmd_rebuild_fts, cmd_orphans
"""

import sys
import json
import sqlite3
import time
import hashlib
import logging
from datetime import datetime, timedelta
from pathlib import Path

from t9os.lib.parsers import parse_md, write_md
from t9os.lib.config import DB_PATH, DATA_DIR

_log = logging.getLogger("t9_seed")

# Path constants
_FIELD = DATA_DIR / "field" / "inbox"
_MEMORY = DATA_DIR / "memory"
_SEDIMENT = DATA_DIR / "spaces" / "sediment"
_LEGACY_DB = DATA_DIR / ".t9_legacy.db"
_LOGS_DIR = DATA_DIR / "logs"
_LEARNED_PATH = DATA_DIR / "telos" / "LEARNED.md"

_SCAN_DIRS = [
    _FIELD, DATA_DIR / "spaces" / "active", DATA_DIR / "spaces" / "suspended",
    DATA_DIR / "spaces" / "archived", _SEDIMENT, _MEMORY, DATA_DIR / "artifacts",
    DATA_DIR / "field" / "impulses", DATA_DIR / "field" / "scraps", DATA_DIR / "telos",
    DATA_DIR / "constitution", DATA_DIR / "data" / "conversations",
    DATA_DIR / "decisions", DATA_DIR / "data" / "composes",
]
_SCAN_EXTS = {
    ".md", ".docx", ".xlsx", ".pdf", ".hwp", ".txt", ".csv", ".log",
    ".zip", ".jpg", ".jpeg", ".png", ".mp4", ".svg",
}


def cmd_reflect(get_db):
    conn = get_db()
    now = datetime.now()
    wa = (now - timedelta(days=7)).strftime("%Y-%m-%d")
    print(f"\n  === T9 Reflection ({wa} ~ {now:%Y-%m-%d}) ===\n")
    trans = conn.execute(
        "SELECT t.*,e.filename,e.metadata FROM transitions t JOIN entities e ON t.entity_id=e.id "
        "WHERE t.timestamp>=? ORDER BY t.timestamp", (wa,)
    ).fetchall()
    if not trans:
        print("  No transitions found.\n")
        conn.close()
        return
    comp = [t for t in trans if t["to_phase"] == "archived"]
    diss = [t for t in trans if t["to_phase"] == "dissolved"]
    susp = [t for t in trans if t["to_phase"] == "suspended"]
    prom = [t for t in trans if t["to_phase"] in ("individuating", "stabilized", "candidate_generated", "tension_detected")]
    print(f"  {len(trans)} items: completed {len(comp)}, dissolved {len(diss)}, suspended {len(susp)}, promoted {len(prom)}")
    if comp:
        print("  Completed:")
        for t in comp:
            print(f"    {t['filename'][:50]}")
    if diss:
        print("  Dissolved:")
        for t in diss:
            print(f"    {t['filename'][:50]} ({t['reason'] or '-'})")
    sug = []
    if not comp:
        sug.append("No completions -- check WIP items")
    if len(prom) >= 5 and not comp:
        sug.append("Many promotions but no completions")
    if len(diss) >= 3:
        sug.append(f"{len(diss)} dissolved -- review scope")
    if sug:
        print("  Suggestions:")
        for s in sug:
            print(f"    * {s}")
    _LEARNED_PATH.parent.mkdir(parents=True, exist_ok=True)
    entry = f"\n## Weekly reflection -- {now:%Y-%m-%d}\n- Total: {len(trans)} (completed {len(comp)}/dissolved {len(diss)}/suspended {len(susp)})\n"
    for s in sug:
        entry += f"- {s}\n"
    existing = _LEARNED_PATH.read_text(encoding="utf-8") if _LEARNED_PATH.exists() else "# T9 LEARNED\n\n"
    _LEARNED_PATH.write_bytes((existing + entry + "\n").encode("utf-8"))
    print(f"\n  Recorded: {_LEARNED_PATH.name}\n")
    conn.close()


def cmd_consolidate(get_db, fhash, _upsert, _preview_len):
    conn = get_db()
    print(f"\n  === T9 Memory Consolidation ===\n")
    archived = conn.execute(
        "SELECT * FROM entities WHERE phase IN ('archived','dissolved') ORDER BY updated_at DESC"
    ).fetchall()
    if not archived:
        print("  No archived entities.\n")
        conn.close()
        return
    _MEMORY.mkdir(parents=True, exist_ok=True)
    groups = {}
    for it in archived:
        concepts_list = []
        if it["concepts"]:
            try:
                concepts_list = json.loads(it["concepts"])
            except Exception:
                pass
        if not concepts_list:
            m = json.loads(it["metadata"]) if it["metadata"] else {}
            concepts_list = m.get("concepts", [])
        key = concepts_list[0] if isinstance(concepts_list, list) and concepts_list else "misc"
        groups.setdefault(key, []).append(it)
    total = 0
    for concept, items in groups.items():
        mp = _MEMORY / f"memory_{concept}.md"
        ex = mp.read_text(encoding="utf-8") if mp.exists() else f"# Memory: {concept}\n\n"
        new = [i for i in items if f"<!-- eid:{i['id']} -->" not in ex]
        if not new:
            continue
        sec = f"\n## Integrate -- {datetime.now():%Y-%m-%d %H:%M}\n\n"
        for i in new:
            sec += f"- <!-- eid:{i['id']} --> **{i['filename']}** ({i['phase']})\n"
            pv = (i["body_preview"] or "")[:80].replace("\n", " ")
            if pv:
                sec += f"  > {pv}\n"
        mp.write_bytes((ex + sec + "\n").encode("utf-8"))
        total += len(new)
        print(f"  [{concept}] {len(new)} items -> memory_{concept}.md")
    for md in _MEMORY.glob("*.md"):
        if not md.name.startswith("."):
            try:
                m2, b2 = parse_md(md)
                _upsert(
                    conn, f"memory/{md.name}", md.name, m2.get("phase", "stabilized"),
                    json.dumps(m2, ensure_ascii=False), b2[:500], fhash(md)
                )
            except Exception as e:
                _log.debug("consolidate parse failed for %s: %s", md.name, e)
    conn.commit()
    conn.close()
    print(f"\n  {total} items integrated.\n")


def cmd_watch(get_db, fhash, cmd_reindex, interval=5):
    print(f"\n  === T9 file monitoring ({interval}s) ===\n  Ctrl+C to end\n")

    def hmap():
        hm = {}
        for sd in _SCAN_DIRS:
            if sd.exists():
                for ext in _SCAN_EXTS:
                    for f in sd.rglob(f"*{ext}"):
                        if not f.name.startswith("."):
                            hm[str(f.relative_to(DATA_DIR))] = fhash(f)
        return hm

    prev = hmap()
    try:
        while True:
            time.sleep(interval)
            curr = hmap()
            ch = False
            for p, h in curr.items():
                if p not in prev or prev[p] != h:
                    print(f"  [change] {p}")
                    ch = True
            for p in prev:
                if p not in curr:
                    print(f"  [delete] {p}")
                    ch = True
            if ch:
                cmd_reindex()
            prev = curr
    except KeyboardInterrupt:
        print("\n  Monitoring ended.\n")


def cmd_history(get_db, eid):
    conn = get_db()
    row = conn.execute("SELECT * FROM entities WHERE id=?", (eid,)).fetchone()
    if not row:
        print(f"  ID {eid} not found")
        conn.close()
        return
    print(f"\n  === Transition history: [{eid}] {row['filename']} ===")
    print(f"  Current: {row['phase']}  Path: {row['filepath']}")
    if row["created_at"]:
        print(f"  Created: {row['created_at'][:16]}")
    if row["parent_id"]:
        print(f"  Parent: [{row['parent_id']}]")
    if row["urgency"]:
        print(f"  Urgency: {row['urgency']}")
    if row["concepts"]:
        try:
            c = json.loads(row["concepts"])
            print(f"  Concepts: {', '.join(c)}")
        except Exception:
            pass
    m = json.loads(row["metadata"]) if row["metadata"] else {}
    rel = m.get("related_to", [])
    if rel:
        print(f"  Related (metadata): {rel}")
    rels = conn.execute(
        "SELECT r.*, e1.filename as src_name, e2.filename as tgt_name "
        "FROM relates r "
        "LEFT JOIN entities e1 ON r.source_id=e1.id "
        "LEFT JOIN entities e2 ON r.target_id=e2.id "
        "WHERE r.source_id=? OR r.target_id=?", (eid, eid)
    ).fetchall()
    if rels:
        print(f"  Relations (transduction):")
        for r in rels:
            arrow = "->" if r["direction"] == "source_to_target" else "<->"
            desc = f" ({r['description']})" if r["description"] else ""
            print(f"    [{r['source_id']}] {r['src_name'] or '?'} {arrow} [{r['target_id']}] {r['tgt_name'] or '?'}{desc}")
    ts = conn.execute(
        "SELECT * FROM transitions WHERE entity_id=? ORDER BY timestamp", (eid,)
    ).fetchall()
    if ts:
        print()
        for t in ts:
            print(f"  {t['timestamp'][:16]}  {t['from_phase'] or '(start)'} -> {t['to_phase']}")
            if t["reason"]:
                print(f"                    reason: {t['reason']}")
    else:
        print("\n  No transition history.")
    print()
    conn.close()


def cmd_relate(get_db, self_check, id1, id2, direction="bidirectional", description=""):
    """Create entity relation (transduction record)."""
    conn = get_db()
    for eid in (id1, id2):
        row = conn.execute("SELECT id FROM entities WHERE id=?", (eid,)).fetchone()
        if not row:
            print(f"  ID {eid} not found")
            conn.close()
            return

    try:
        conn.execute(
            "INSERT OR REPLACE INTO relates (source_id, target_id, direction, description, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (id1, id2, direction, description, datetime.now().isoformat())
        )
    except sqlite3.IntegrityError:
        conn.execute(
            "UPDATE relates SET direction=?, description=?, created_at=? "
            "WHERE source_id=? AND target_id=?",
            (direction, description, datetime.now().isoformat(), id1, id2)
        )

    if direction == "bidirectional":
        try:
            conn.execute(
                "INSERT OR REPLACE INTO relates (source_id, target_id, direction, description, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (id2, id1, "bidirectional", description, datetime.now().isoformat())
            )
        except Exception as e:
            _log.debug("reverse relate failed: %s", e)

    for eid, other in [(id1, id2), (id2, id1)]:
        row = conn.execute("SELECT * FROM entities WHERE id=?", (eid,)).fetchone()
        m = json.loads(row["metadata"]) if row["metadata"] else {}
        rel = m.get("related_to", [])
        if other not in rel:
            rel.append(other)
        m["related_to"] = rel
        conn.execute(
            "UPDATE entities SET metadata=?,updated_at=? WHERE id=?",
            (json.dumps(m, ensure_ascii=False), datetime.now().isoformat(), eid)
        )
        fp = DATA_DIR / row["filepath"]
        if fp.exists() and fp.suffix == ".md":
            fm, body = parse_md(fp)
            fm["related_to"] = rel
            self_check("relate", fm)
            write_md(fp, fm, body)

    conn.commit()
    conn.close()
    arrow = "->" if direction == "source_to_target" else "<->"
    desc_str = f" ({description})" if description else ""
    print(f"  Connected: [{id1}] {arrow} [{id2}]{desc_str}\n")


def cmd_digest_index(get_db, fhash, _upsert, _preview_len):
    """Index digest files into FTS."""
    conn = get_db()
    count = 0
    print(f"  Digest indexing not available in standalone mode.")
    conn.close()


def cmd_legacy(query):
    if not _LEGACY_DB.exists():
        print(f"  Legacy DB not found")
        return
    conn = sqlite3.connect(str(_LEGACY_DB))
    conn.row_factory = sqlite3.Row
    rs = conn.execute(
        "SELECT id,path,name,ext,dir,content_summary,ai_tags FROM files "
        "WHERE name LIKE ? OR path LIKE ? OR content_summary LIKE ? OR ai_tags LIKE ? "
        "ORDER BY modified DESC LIMIT 20",
        (f"%{query}%",) * 4
    ).fetchall()
    if not rs:
        print(f"  No results for: '{query}'")
    else:
        print(f"\n  === Legacy search: '{query}' ({len(rs)} items) ===\n")
        for r in rs:
            print(f"  [{r['id']:4d}] {r['name'][:40]:40s} | {r['dir'] or '-'}")
            s = (r["content_summary"] or "")[:60].replace("\n", " ")
            if s:
                print(f"         {s}")
    conn.close()
    print()


def cmd_ingest(cmd_capture, filepath):
    """Ingest external file as preindividual entities."""
    import shutil
    fp = Path(filepath)
    if not fp.exists():
        print(f'  File not found: {filepath}')
        return
    dest = _FIELD / fp.name
    if not dest.exists():
        _FIELD.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(fp), str(dest))
        print(f'  Saved: {dest.name}')
    text = fp.read_text(encoding='utf-8', errors='replace')
    messages = []
    for line in text.split(chr(10)):
        line = line.strip()
        if not line or line.startswith('---'):
            continue
        if '] ' in line:
            parts = line.split('] ', 2)
            if len(parts) >= 3:
                msg = parts[-1].strip()
                if len(msg) > 15:
                    messages.append(msg)
            elif len(parts) == 2:
                msg = parts[-1].strip()
                if len(msg) > 15:
                    messages.append(msg)
    count = 0
    for msg in messages:
        if len(msg) > 20:
            cmd_capture(msg)
            count += 1
    print(f'  {count} items registered (from {len(messages)} messages)')


def cmd_resurface(get_db, keyword=""):
    """Resurface sediment entities."""
    import random
    conn = get_db()
    if keyword:
        results = conn.execute(
            "SELECT id,filename,body_preview,concepts,updated_at FROM entities "
            "WHERE phase='sediment' AND (filename LIKE ? OR body_preview LIKE ? OR metadata LIKE ?) "
            "ORDER BY updated_at DESC LIMIT 10",
            (f"%{keyword}%",) * 3
        ).fetchall()
    else:
        all_sed = conn.execute(
            "SELECT id,filename,body_preview,concepts,updated_at FROM entities "
            "WHERE phase='sediment'"
        ).fetchall()
        count = min(max(3, len(all_sed)), 5) if all_sed else 0
        results = random.sample(list(all_sed), count) if count else []
    if not results:
        print("  No sediment entities found." + (f" (keyword: {keyword})" if keyword else ""))
        conn.close()
        return
    print(f"\n  === Sediment (resurface) ===" + (f" keyword: {keyword}" if keyword else "") + f" ({len(results)} items)\n")
    for r in results:
        preview = (r["body_preview"] or "")[:80].replace("\n", " ")
        tags = ""
        if r["concepts"]:
            try:
                tags = ", ".join(json.loads(r["concepts"]))
            except Exception:
                pass
        print(f"  [{r['id']:3d}] {r['filename'][:50]}")
        if preview:
            print(f"         {preview}")
        if tags:
            print(f"         Concepts: {tags}")
        print(f"         Last updated: {(r['updated_at'] or '')[:10]}")
        print()
    print("  -> t9 transition <id> reactivated\n")
    conn.close()


def cmd_rebuild_fts(get_db):
    """Rebuild FTS5 search index."""
    conn = get_db()
    print("  FTS5 index rebuild starting...")
    try:
        conn.execute("DROP TABLE IF EXISTS entities_fts")
        conn.execute("CREATE VIRTUAL TABLE entities_fts USING fts5(filename, body_preview, metadata_text)")
    except Exception as e:
        print(f"  [ERROR] FTS5 table create failed: {e}")
        conn.close()
        return
    rows = conn.execute("SELECT id, filename, body_preview, metadata FROM entities").fetchall()
    count = 0
    for r in rows:
        try:
            conn.execute(
                "INSERT INTO entities_fts(rowid, filename, body_preview, metadata_text) VALUES(?,?,?,?)",
                (r["id"], r["filename"], r["body_preview"] or "", r["metadata"] or "")
            )
            count += 1
        except Exception as e:
            _log.debug("FTS rebuild skip [%d] %s: %s", r["id"], r["filename"], e)
    conn.commit()
    conn.close()
    print(f"  FTS5 rebuild complete: {count}/{len(rows)} items indexed")


def cmd_orphans(get_db):
    """Detect orphan entities (DB records without files)."""
    fix = "--fix" in sys.argv
    conn = get_db()
    rows = conn.execute(
        "SELECT id, filepath, filename, phase FROM entities WHERE filepath IS NOT NULL AND filepath != ''"
    ).fetchall()
    orphans, corrupted = [], []
    for r in rows:
        if not isinstance(r["filepath"], str):
            corrupted.append(r)
            continue
        fp = DATA_DIR / r["filepath"]
        if not fp.exists():
            orphans.append(r)
    if corrupted:
        print(f"\n  === Corrupted entries: {len(corrupted)} ===")
        for r in corrupted:
            print(f"  [{r['id']:4d}] filepath={repr(r['filepath'])}")
        if fix:
            for r in corrupted:
                conn.execute("DELETE FROM entities WHERE id=?", (r["id"],))
            conn.commit()
            print(f"  {len(corrupted)} corrupted entries deleted")
    if not orphans:
        print("  No orphans found")
    else:
        print(f"\n  === Orphans: {len(orphans)} (file not found) ===\n")
        for r in orphans:
            print(f"  [{r['id']:4d}] {r['phase']:15s} | {r['filename'][:50]}")
            print(f"         path: {r['filepath']}")
        if fix:
            for r in orphans:
                conn.execute(
                    "UPDATE entities SET phase='sediment', updated_at=? WHERE id=?",
                    (datetime.now().isoformat(), r["id"])
                )
                conn.execute(
                    "INSERT INTO transitions (entity_id,from_phase,to_phase,timestamp,reason) VALUES(?,?,?,?,?)",
                    (r["id"], r["phase"], "sediment", datetime.now().isoformat(), "orphan: file missing")
                )
            conn.commit()
            print(f"\n  {len(orphans)} orphans -> sediment")
        else:
            print(f"\n  Use --fix to move orphans to sediment: t9 orphans --fix")
    conn.close()
