"""T9 OS pipeline registry — single source (SRBB compliance)."""

from pathlib import Path

# Note: In packaged mode, paths are relative to DATA_DIR
# Registry entries use string keys instead of absolute paths

PIPELINE_REGISTRY = [
    {"file": "engine/seed.py", "desc": "Seed engine", "type": "engine"},
    {"file": "pipes/t9_bot.py", "desc": "Telegram bot", "type": "daemon"},
    {"file": "pipes/t9_auto.py", "desc": "Preindividual auto classify", "type": "cron"},
    {"file": "pipes/gm_batch.py", "desc": "Guardian batch", "type": "manual"},
    {"file": "pipes/deadline_notify.py", "desc": "Deadline notification", "type": "cron"},
    {"file": "pipes/t9_ceo_brief.py", "desc": "CEO brief", "type": "cron"},
    {"file": "pipes/calendar_sync.py", "desc": "Calendar sync", "type": "cron"},
    {"file": "pipes/integrity_check.py", "desc": "Integrity check", "type": "check"},
    {"file": "pipes/healthcheck.py", "desc": "Health check", "type": "check"},
    {"file": "pipes/session_lock.py", "desc": "Session lock", "type": "lib"},
    {"file": "pipes/session_live_read.py", "desc": "Session JSONL reader", "type": "lib"},
    {"file": "pipes/safe_change.sh", "desc": "Change safety net", "type": "tool"},
    {"file": "pipes/tg_common.py", "desc": "Telegram common", "type": "lib"},
    {"file": "pipes/adr_auto.py", "desc": "ADR auto create", "type": "hook"},
    {"file": "pipes/cron_runner.sh", "desc": "Cron runner", "type": "tool"},
    {"file": "pipes/hwp_convert.py", "desc": "HWP<->DOCX", "type": "tool"},
    {"file": "pipes/gdrive_upload.py", "desc": "Google Drive upload", "type": "tool"},
]

DAEMON_PROCESSES = ["t9_bot.py"]
CRON_IDENTIFIERS = ["deadline", "ceo_brief", "calendar", "healthcheck", "t9_auto"]
