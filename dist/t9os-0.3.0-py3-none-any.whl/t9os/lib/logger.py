"""T9 OS pipeline logger — execution result record + failed Telegram notification.

Usage:
    from t9os.lib.logger import pipeline_run, log_error

    with pipeline_run("deadline_notify"):
        notify()
"""

import json
import traceback
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

from t9os.lib.config import TG_TOKEN, TG_CHAT, LOG_DIR, T9

STATUS_FILE = T9 / ".pipe_status.json"


def _load_status() -> dict:
    if STATUS_FILE.exists():
        try:
            return json.loads(STATUS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save_status(data: dict):
    STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATUS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _tg_send_raw(text: str):
    """Send Telegram notification (standalone, no tg_common dependency)."""
    if not TG_TOKEN or not TG_CHAT:
        return
    import urllib.parse
    import urllib.request
    api = f"https://api.telegram.org/bot{TG_TOKEN}"
    for i in range(0, max(len(text), 1), 4000):
        chunk = text[i:i + 4000]
        data = urllib.parse.urlencode({"chat_id": TG_CHAT, "text": chunk}).encode()
        try:
            urllib.request.urlopen(f"{api}/sendMessage", data, timeout=10)
        except Exception:
            pass


def record(pipeline: str, status: str, detail: str = ""):
    """Record pipeline execution result."""
    data = _load_status()
    data[pipeline] = {
        "status": status,
        "time": _now(),
        "detail": detail[:500] if detail else "",
    }
    _save_status(data)


def log_error(pipeline: str, error: Exception, notify: bool = True):
    """Record error + optional Telegram notification."""
    tb = traceback.format_exception(type(error), error, error.__traceback__)
    detail = "".join(tb[-3:])
    record(pipeline, "FAIL", detail)

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_file = LOG_DIR / f"{datetime.now():%Y%m%d}_pipe_errors.log"
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"\n[{_now()}] {pipeline} FAIL\n{detail}\n")

    if notify:
        _tg_send_raw(f"T9 pipeline failed\n\n{pipeline}\n{str(error)[:200]}")


@contextmanager
def pipeline_run(name: str, notify_on_fail: bool = True):
    """Pipeline execution context manager. Auto-records success/failure."""
    try:
        yield
        record(name, "OK")
    except Exception as e:
        log_error(name, e, notify=notify_on_fail)
        raise


def get_all_status() -> dict:
    """Return all pipeline status (for healthcheck)."""
    return _load_status()
