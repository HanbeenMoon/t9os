"""T9 OS shared config — XDG-based paths + env vars + config.toml.

All pipelines import from this module.
No duplicate loading code in individual pipelines.

Usage:
    from t9os.lib.config import DB_PATH, CONFIG_DIR, DATA_DIR
    from t9os.lib.config import get  # env var lookup
"""

import os
from pathlib import Path

# ─── XDG-based path resolution ─────────────────────────────────
# CONFIG_DIR: user configuration (constitution, telos, config.toml)
# DATA_DIR: runtime data (DB, spaces, field, etc.)
# These can be overridden via environment variables.

CONFIG_DIR = Path(os.environ.get("T9OS_CONFIG_DIR", Path.home() / ".config" / "t9os"))
DATA_DIR = Path(os.environ.get("T9OS_DATA_DIR", Path.home() / ".t9os_data"))
DB_PATH = Path(os.environ.get("T9OS_DB_PATH", DATA_DIR / ".t9.db"))

# Legacy path support: if running inside a T9OS repo checkout,
# use the repo-relative DB as fallback
_REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent  # src/t9os/lib/ -> repo root
_REPO_DB = _REPO_ROOT / ".t9.db"
if not DB_PATH.exists() and _REPO_DB.exists():
    DB_PATH = _REPO_DB

# Convenience paths derived from DATA_DIR
INBOX_DIR = DATA_DIR / "field" / "inbox"
LOG_DIR = DATA_DIR / "logs"

# T9 compatibility alias (points to DATA_DIR for runtime, CONFIG_DIR for config)
T9 = DATA_DIR


# ─── Env var loading (single entry point) ──────────────────────
_ENV_FILES_CANDIDATES = [
    Path.home() / ".config" / "t9os" / ".env",   # XDG location
    Path(os.environ.get("T9OS_ENV_FILE", "")) if os.environ.get("T9OS_ENV_FILE") else None,
]
# Filter None and non-existent
_ENV_FILES = [f for f in _ENV_FILES_CANDIDATES if f and f.exists()]

_loaded: dict[str, str] = {}


def _parse_env_file(path: Path) -> dict[str, str]:
    """Parse KEY=VALUE or export KEY=VALUE format files."""
    if not path.exists():
        return {}
    result: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:]
        if "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip().strip('"').strip("'").strip('\r\n')
        result[k] = v
    return result


def _load_all() -> dict[str, str]:
    """Load all env files. os.environ takes priority."""
    global _loaded
    if _loaded:
        return _loaded
    merged: dict[str, str] = {}
    for f in reversed(_ENV_FILES):
        merged.update(_parse_env_file(f))
    merged.update({k: v.strip('\r\n') for k, v in os.environ.items()})
    _loaded = merged
    return _loaded


def get(key: str, default: str = "") -> str:
    """Env var lookup. os.environ > env file priority."""
    return _load_all().get(key, default)


def reload_env() -> None:
    """Force reload env vars (useful after config change)."""
    global _loaded
    _loaded = {}
    _load_all()


# ─── config.toml support ───────────────────────────────────────

_config_toml: dict | None = None


def load_config_toml() -> dict:
    """Load config.toml from CONFIG_DIR. Returns empty dict if not found."""
    global _config_toml
    if _config_toml is not None:
        return _config_toml

    config_file = CONFIG_DIR / "config.toml"
    if not config_file.exists():
        _config_toml = {}
        return _config_toml

    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            # Fallback: basic TOML parser for simple key=value
            _config_toml = _parse_simple_toml(config_file)
            return _config_toml

    _config_toml = tomllib.loads(config_file.read_text(encoding="utf-8"))
    return _config_toml


def _parse_simple_toml(path: Path) -> dict:
    """Minimal TOML parser for simple key=value pairs (no nested tables)."""
    result: dict = {}
    current_section = result
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            result[section] = {}
            current_section = result[section]
            continue
        if "=" in line:
            k, _, v = line.partition("=")
            k = k.strip()
            v = v.strip().strip('"').strip("'")
            if v.lower() in ("true", "false"):
                v = v.lower() == "true"  # type: ignore[assignment]
            current_section[k] = v
    return result


# ─── Frequently used keys (available on import) ────────────────

def _init_keys():
    """Initialize keys on module load."""
    env = _load_all()
    return {
        "GEMINI_KEY": env.get("GEMINI_API_KEY", env.get("GOOGLE_API_KEY", "")),
        "TG_TOKEN": env.get("T9_TG_TOKEN", ""),
        "TG_CHAT": env.get("T9_TG_CHAT", ""),
        "NOTION_TOKEN": env.get("T9_NOTION_TOKEN", env.get("NOTION_TOKEN", "")),
        "GITHUB_TOKEN": env.get("GITHUB_TOKEN", ""),
        "OPENAI_KEY": env.get("OPENAI_API_KEY", ""),
        "ANTHROPIC_KEY": env.get("ANTHROPIC_API_KEY", ""),
        "CANVAS_TOKEN": env.get("CANVAS_TOKEN", ""),
        "GOOGLE_CLIENT_ID": env.get("GOOGLE_CLIENT_ID", ""),
        "GOOGLE_CLIENT_SECRET": env.get("GOOGLE_CLIENT_SECRET", ""),
        "GOOGLE_REFRESH_TOKEN": env.get("GOOGLE_REFRESH_TOKEN", ""),
    }


_keys = _init_keys()

GEMINI_KEY: str = _keys["GEMINI_KEY"]
TG_TOKEN: str = _keys["TG_TOKEN"]
TG_CHAT: str = _keys["TG_CHAT"]
NOTION_TOKEN: str = _keys["NOTION_TOKEN"]
GITHUB_TOKEN: str = _keys["GITHUB_TOKEN"]
OPENAI_KEY: str = _keys["OPENAI_KEY"]
ANTHROPIC_KEY: str = _keys["ANTHROPIC_KEY"]
CANVAS_TOKEN: str = _keys["CANVAS_TOKEN"]
GOOGLE_CLIENT_ID: str = _keys["GOOGLE_CLIENT_ID"]
GOOGLE_CLIENT_SECRET: str = _keys["GOOGLE_CLIENT_SECRET"]
GOOGLE_REFRESH_TOKEN: str = _keys["GOOGLE_REFRESH_TOKEN"]
