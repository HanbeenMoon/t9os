"""T9 OS JSON Export."""

import json
import sqlite3
from datetime import datetime
from pathlib import Path

from t9os.lib.config import DB_PATH, DATA_DIR


def cmd_export_json():
    """Export entities + transitions as JSON to stdout."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row

    entities = []
    for r in conn.execute(
        "SELECT id, filepath, filename, phase, metadata, body_preview, "
        "urgency, concepts, created_at, updated_at FROM entities ORDER BY updated_at DESC"
    ):
        meta = {}
        try:
            meta = json.loads(r["metadata"]) if r["metadata"] else {}
        except (json.JSONDecodeError, TypeError):
            pass
        entities.append({
            "id": r["id"], "filepath": r["filepath"], "filename": r["filename"],
            "phase": r["phase"], "urgency": r["urgency"] or meta.get("urgency", ""),
            "concepts": r["concepts"] or ",".join(meta.get("concepts", [])),
            "body_preview": (r["body_preview"] or "")[:200],
            "created_at": r["created_at"] or "", "updated_at": r["updated_at"] or "",
        })

    phase_counts = {}
    for r in conn.execute("SELECT phase, COUNT(*) as cnt FROM entities GROUP BY phase"):
        phase_counts[r["phase"]] = r["cnt"]

    transitions = []
    for r in conn.execute(
        "SELECT t.id, t.entity_id, t.from_phase, t.to_phase, t.timestamp, t.reason, "
        "e.filename FROM transitions t LEFT JOIN entities e ON t.entity_id = e.id "
        "ORDER BY t.timestamp DESC LIMIT 50"
    ):
        transitions.append({
            "id": r["id"], "entity_id": r["entity_id"],
            "from_phase": r["from_phase"], "to_phase": r["to_phase"],
            "timestamp": r["timestamp"], "reason": (r["reason"] or "")[:200],
            "filename": r["filename"] or "",
        })

    urgent = [e for e in entities if e["urgency"] == "high" and e["phase"] not in ("dissolved", "archived")]
    individuating = [e for e in entities if e["phase"] == "individuating"]
    tension = [e for e in entities if e["phase"] == "tension_detected"]

    result = {
        "exported_at": datetime.now().isoformat(),
        "phase_counts": phase_counts,
        "total_entities": len(entities),
        "entities": entities,
        "transitions": transitions,
        "urgent": urgent,
        "individuating": individuating,
        "tension": tension,
        "deadlines": [],
    }

    conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
