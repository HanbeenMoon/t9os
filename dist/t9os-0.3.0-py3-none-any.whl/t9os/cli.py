"""T9 OS CLI — Typer-based command-line interface.

Usage:
    t9 daily          # Daily brief
    t9 capture <text> # Save preindividual
    t9 status         # Overall status
    t9 search <query> # Search entities
    t9 init           # Initialize T9 OS data directory
"""

from __future__ import annotations

import shutil
import sys
from pathlib import Path
from typing import Optional

try:
    import typer
    from typer import Argument, Option
except ImportError:
    print("Error: typer is required. Install with: pip install 't9os[all]' or pip install typer[all]")
    sys.exit(1)

from t9os import __version__

app = typer.Typer(
    name="t9",
    help="T9 OS -- A Simondonian AI operating system for life orchestration.",
    no_args_is_help=True,
    add_completion=False,
)


def _version_callback(value: bool):
    if value:
        print(f"T9 OS v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = Option(None, "--version", "-V", callback=_version_callback, is_eager=True,
                           help="Show version and exit."),
):
    """T9 OS -- The starting point is not Task but Tension."""
    pass


# ─── Init ────────────────────────────────────────────────────

@app.command()
def init(
    quick: bool = Option(False, "--quick", "-q", help="Skip questions, use defaults."),
):
    """Initialize T9 OS data directory and configuration."""
    from t9os.lib.config import CONFIG_DIR, DATA_DIR, DB_PATH

    print(f"\n  === T9 OS v{__version__} -- Initialization ===\n")

    # Create config directory
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    print(f"  Config: {CONFIG_DIR}")

    # Create data directories
    data_dirs = [
        DATA_DIR / "field" / "inbox",
        DATA_DIR / "field" / "impulses",
        DATA_DIR / "field" / "scraps",
        DATA_DIR / "spaces" / "active",
        DATA_DIR / "spaces" / "suspended",
        DATA_DIR / "spaces" / "archived",
        DATA_DIR / "spaces" / "sediment",
        DATA_DIR / "memory",
        DATA_DIR / "artifacts",
        DATA_DIR / "logs",
        DATA_DIR / "data" / "conversations",
        DATA_DIR / "data" / "composes",
        DATA_DIR / "decisions",
        DATA_DIR / "telos",
        DATA_DIR / "constitution",
    ]
    for d in data_dirs:
        d.mkdir(parents=True, exist_ok=True)
    print(f"  Data:   {DATA_DIR}")

    # Copy templates
    templates_dir = Path(__file__).parent / "templates"
    if templates_dir.exists():
        # Constitution
        const_src = templates_dir / "constitution"
        const_dst = CONFIG_DIR / "constitution"
        if const_src.exists():
            const_dst.mkdir(parents=True, exist_ok=True)
            for f in const_src.iterdir():
                dst = const_dst / f.name
                if not dst.exists():
                    shutil.copy2(str(f), str(dst))
                    print(f"  Template: constitution/{f.name}")

            # Also copy to data dir for engine access
            data_const = DATA_DIR / "constitution"
            data_const.mkdir(parents=True, exist_ok=True)
            for f in const_src.iterdir():
                dst = data_const / f.name
                if not dst.exists():
                    shutil.copy2(str(f), str(dst))

        # Telos
        telos_src = templates_dir / "telos"
        telos_dst = CONFIG_DIR / "telos"
        if telos_src.exists():
            telos_dst.mkdir(parents=True, exist_ok=True)
            for f in telos_src.iterdir():
                dst = telos_dst / f.name
                if not dst.exists():
                    shutil.copy2(str(f), str(dst))
                    print(f"  Template: telos/{f.name}")

            data_telos = DATA_DIR / "telos"
            data_telos.mkdir(parents=True, exist_ok=True)
            for f in telos_src.iterdir():
                dst = data_telos / f.name
                if not dst.exists():
                    shutil.copy2(str(f), str(dst))

        # config.toml
        toml_src = templates_dir / "config.toml.default"
        toml_dst = CONFIG_DIR / "config.toml"
        if toml_src.exists() and not toml_dst.exists():
            shutil.copy2(str(toml_src), str(toml_dst))
            print(f"  Config:  config.toml")

    # Initialize DB
    from t9os.engine.seed import get_db
    conn = get_db()
    entity_count = conn.execute("SELECT COUNT(*) as c FROM entities").fetchone()["c"]
    conn.close()
    print(f"  DB:     {DB_PATH} ({entity_count} entities)")

    print(f"\n  T9 OS initialized. Run 't9 daily' for your daily brief.\n")


# ─── Core Commands ───────────────────────────────────────────

@app.command()
def daily():
    """Daily brief: deadlines, active work, transductive suggestions."""
    from t9os.engine.seed import cmd_daily
    cmd_daily()


@app.command()
def capture(
    text: list[str] = Argument(..., help="Text to capture as preindividual."),
):
    """Save a preindividual entity (raw idea, tension, input)."""
    from t9os.engine.seed import cmd_capture
    cmd_capture(" ".join(text))


@app.command()
def status():
    """Show overall entity counts by phase."""
    from t9os.engine.seed import cmd_status
    cmd_status()


@app.command()
def search(
    query: list[str] = Argument(..., help="Search query."),
):
    """Search entities by keyword."""
    from t9os.engine.seed import cmd_search
    cmd_search(" ".join(query))


@app.command()
def transition(
    entity_id: int = Argument(..., help="Entity ID."),
    phase: str = Argument(..., help="Target phase."),
    reason: Optional[str] = Argument(None, help="Reason for transition."),
):
    """Transition an entity to a new phase."""
    from t9os.engine.seed import cmd_transition
    cmd_transition(entity_id, phase, reason or "")


@app.command()
def reindex(
    incremental: bool = Option(False, "--incremental", "-i", help="Skip unchanged files."),
):
    """Rebuild entity index from files."""
    from t9os.engine.seed import cmd_reindex
    cmd_reindex(incremental=incremental)


@app.command()
def compose(
    text: list[str] = Argument(..., help="Task description to compose plans for."),
):
    """Generate execution plans from a task description."""
    from t9os.engine.seed import cmd_compose
    cmd_compose(" ".join(text))


@app.command()
def approve(
    compose_id: str = Argument(..., help="Compose ID."),
    plan: str = Argument(..., help="Plan letter (A/B/C)."),
):
    """Approve a generated plan."""
    from t9os.engine.seed import cmd_approve
    cmd_approve(compose_id, plan)


@app.command()
def reflect():
    """Weekly reflection: review transitions and suggest improvements."""
    from t9os.engine.seed import cmd_reflect
    cmd_reflect()


@app.command()
def consolidate():
    """Consolidate archived entities into memory files."""
    from t9os.engine.seed import cmd_consolidate
    cmd_consolidate()


@app.command()
def history(
    entity_id: int = Argument(..., help="Entity ID."),
):
    """Show transition history for an entity."""
    from t9os.engine.seed import cmd_history
    cmd_history(entity_id)


@app.command()
def relate(
    id1: int = Argument(..., help="First entity ID."),
    id2: int = Argument(..., help="Second entity ID."),
    direction: str = Option("bidirectional", "--direction", "-d", help="Relation direction."),
    description: str = Option("", "--desc", help="Relation description."),
):
    """Connect two entities (transduction record)."""
    from t9os.engine.seed import cmd_relate
    cmd_relate(id1, id2, direction, description)


@app.command()
def done(
    entity_id: int = Argument(..., help="Entity ID."),
    reason: Optional[str] = Argument(None, help="Completion note."),
):
    """Mark entity as stabilized (done)."""
    from t9os.engine.seed import cmd_transition
    cmd_transition(entity_id, "stabilized", reason or "completed")


@app.command()
def go(
    entity_id: int = Argument(..., help="Entity ID."),
    reason: Optional[str] = Argument(None, help="Start note."),
):
    """Start working on an entity (individuating)."""
    from t9os.engine.seed import cmd_transition
    cmd_transition(entity_id, "individuating", reason or "started")


@app.command()
def resurface(
    keyword: Optional[str] = Argument(None, help="Optional keyword filter."),
):
    """Resurface sediment entities (random or keyword search)."""
    from t9os.engine.seed import cmd_resurface
    cmd_resurface(keyword or "")


@app.command()
def tidy():
    """Periodic cleanup: resolve phase-directory mismatches."""
    from t9os.engine.seed import cmd_tidy
    cmd_tidy()


@app.command(name="rebuild-fts")
def rebuild_fts():
    """Rebuild FTS5 full-text search index."""
    from t9os.engine.seed import cmd_rebuild_fts
    cmd_rebuild_fts()


@app.command()
def orphans(
    fix: bool = Option(False, "--fix", help="Move orphans to sediment."),
):
    """Detect orphan entities (DB records without files)."""
    if fix:
        sys.argv.append("--fix")
    from t9os.engine.seed import cmd_orphans
    cmd_orphans()


@app.command()
def deadlines(
    all_: bool = Option(False, "--all", help="Show all deadlines (not just next 30 days)."),
):
    """Show entities with deadlines."""
    from t9os.engine.seed import cmd_deadlines
    cmd_deadlines(show_all=all_)


@app.command(name="export-json")
def export_json():
    """Export all entities and transitions as JSON."""
    from t9os.lib.export import cmd_export_json
    cmd_export_json()


@app.command()
def legacy(
    query: list[str] = Argument(..., help="Search query for legacy DB."),
):
    """Search legacy database."""
    from t9os.engine.seed import cmd_legacy
    cmd_legacy(" ".join(query))


@app.command()
def watch(
    interval: int = Argument(5, help="Watch interval in seconds."),
):
    """Watch for file changes and auto-reindex."""
    from t9os.engine.seed import cmd_watch
    cmd_watch(interval)


@app.command()
def ingest(
    filepath: str = Argument(..., help="File to ingest."),
):
    """Ingest an external file as preindividual entities."""
    from t9os.engine.seed import cmd_ingest
    cmd_ingest(filepath)


@app.command()
def ipc(
    args: list[str] = Argument(..., help="IPC subcommand and arguments."),
):
    """Inter-session communication."""
    from t9os.lib.ipc import cli
    cli(args)


if __name__ == "__main__":
    app()
