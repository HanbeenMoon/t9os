"""T9 OS 12-State Machine — Simondonian phase transitions.

Each entity traverses phases from preindividual potential through
individuation to stabilized form, following Simondon's philosophy
of individuation.
"""

# State transition graph (enhanced: split/merged/reactivated paths)
TRANSITIONS: dict[str, set[str]] = {
    "preindividual":       {"tension_detected", "impulse", "sediment"},
    "impulse":             {"tension_detected", "preindividual", "sediment"},
    "tension_detected":    {"candidate_generated", "suspended", "sediment"},
    "candidate_generated": {"individuating", "suspended", "sediment"},
    "individuating":       {"stabilized", "split", "merged", "suspended"},
    "stabilized":          {"archived", "split", "merged", "suspended", "reactivated"},
    "split":               {"preindividual", "tension_detected", "individuating", "suspended"},
    "merged":              {"preindividual", "tension_detected", "individuating", "suspended"},
    "suspended":           {"reactivated", "archived", "sediment"},
    "archived":            {"reactivated"},
    "reactivated":         {"tension_detected"},
    "sediment":            {"reactivated"},  # can resurface (reactivate) from sediment
    "dissolved":           {"sediment"},     # existing dissolved can also transition to sediment
}

# Phase -> directory key mapping (used by engine to resolve paths)
PHASE_DIR_KEYS: dict[str, str] = {
    "preindividual": "field/inbox",
    "impulse": "field/impulses",
    "tension_detected": "field/inbox",
    "candidate_generated": "field/inbox",
    "individuating": "spaces/active",
    "stabilized": "spaces/active",
    "split": "spaces/active",
    "merged": "spaces/active",
    "reactivated": "spaces/active",
    "suspended": "spaces/suspended",
    "archived": "spaces/archived",
    "dissolved": "spaces/archived",
    "sediment": "spaces/sediment",
}

# Concept keyword mapping
CONCEPT_KW: dict[str, list[str]] = {
    "create":  ["build", "create", "implement", "develop", "make"],
    "explore": ["research", "explore", "investigate", "analyze"],
    "solve":   ["fix", "solve", "debug", "resolve", "repair"],
    "earn":    ["revenue", "money", "earn", "sales", "business"],
    "express": ["present", "write", "express", "essay", "publish"],
    "become":  ["study", "learn", "become", "grow", "learning"],
}

ALL_PHASES = list(TRANSITIONS.keys())
