"""
T9 OS Seed v0.3 -- Simondonian Engine (packaged)
"The starting point is not Task but Tension."
NO "project" field. NO hardcoded classification.

v0.3: Packaged as pip-installable module with XDG paths.
"""

import sys
import os
import re
import sqlite3
import json
import time
import hashlib
import shutil
import logging
from datetime import datetime, timedelta
from pathlib import Path

logging.basicConfig(
    format="[%(asctime)s] %(levelname)s: %(message)s",
    datefmt="%H:%M:%S",
    level=logging.WARNING,
)
_log = logging.getLogger("t9_seed")

from t9os.lib.parsers import parse_file, parse_md, write_md
from t9os.lib.ipc import cli as ipc_cli
from t9os.lib.export import cmd_export_json
from t9os.lib.commands import cmd_daily as _cmd_daily, cmd_tidy as _cmd_tidy
from t9os.lib.commands import cmd_compose as _cmd_compose, cmd_approve as _cmd_approve
from t9os.lib.transduction import find_transductions, format_transduction_report
from t9os.lib.config import DB_PATH, DATA_DIR
from t9os.engine.states import TRANSITIONS, PHASE_DIR_KEYS, CONCEPT_KW
from t9os.lib.commands_ext import (
    cmd_reflect as _cmd_reflect, cmd_consolidate as _cmd_consolidate,
    cmd_watch as _cmd_watch, cmd_history as _cmd_history,
    cmd_relate as _cmd_relate, cmd_digest_index as _cmd_digest_index,
    cmd_legacy as _cmd_legacy, cmd_ingest as _cmd_ingest,
    cmd_resurface as _cmd_resurface, cmd_rebuild_fts as _cmd_rebuild_fts,
    cmd_orphans as _cmd_orphans,
)

# Paths derived from DATA_DIR (XDG-based)
FIELD = DATA_DIR / "field" / "inbox"
ACTIVE = DATA_DIR / "spaces" / "active"
SUSPENDED = DATA_DIR / "spaces" / "suspended"
ARCHIVED = DATA_DIR / "spaces" / "archived"
MEMORY = DATA_DIR / "memory"
SEDIMENT = DATA_DIR / "spaces" / "sediment"
LEGACY_DB = DATA_DIR / ".t9_legacy.db"
LOGS_DIR = DATA_DIR / "logs"
LEARNED_PATH = DATA_DIR / "telos" / "LEARNED.md"
ARTIFACTS = DATA_DIR / "artifacts"
IMPULSES = DATA_DIR / "field" / "impulses"
CONVERSATIONS = DATA_DIR / "data" / "conversations"
DECISIONS = DATA_DIR / "decisions"
COMPOSES = DATA_DIR / "data" / "composes"

# Phase -> directory mapping
PHASE_DIR = {phase: DATA_DIR / rel_path for phase, rel_path in PHASE_DIR_KEYS.items()}

SCAN_DIRS = [
    FIELD, ACTIVE, SUSPENDED, ARCHIVED, SEDIMENT, MEMORY, ARTIFACTS,
    IMPULSES, DATA_DIR / "field" / "scraps", DATA_DIR / "telos",
    DATA_DIR / "constitution", CONVERSATIONS, DECISIONS, COMPOSES,
]
SCAN_EXTS = {
    ".md", ".docx", ".xlsx", ".pdf", ".hwp", ".txt", ".csv", ".log",
    ".zip", ".jpg", ".jpeg", ".png", ".mp4", ".svg",
}


def _preview_len(filepath, body=None):
    """Adaptively determine body_preview length."""
    if body is None:
        body = ""
    total = len(body)
    if total <= 1000:
        return total
    s = str(filepath)
    if 'conversations' in s:
        return min(total, max(3000, total // 3))
    if any(k in s for k in ['session-briefs', 'brief', 'decisions', 'WORKING', 'BIBLE']):
        return min(total, 3000)
    if any(k in s for k in ['constitution', 'telos', 'artifacts']):
        return min(total, 2000)
    if any(s.endswith(ext) for ext in ['.csv', '.log', '.txt']):
        return min(total, 500)
    return min(total, max(500, total // 2))


# --- DB ---

_EXTRA_COLUMNS = {
    "created_at": "TEXT",
    "parent_id": "INTEGER",
    "urgency": "TEXT",
    "concepts": "TEXT",
    "deadline_date": "TEXT",
}


def _migrate_db(conn):
    """Add missing columns via ALTER TABLE if needed."""
    existing_cols = {r[1] for r in conn.execute("PRAGMA table_info(entities)").fetchall()}
    for col, ctype in _EXTRA_COLUMNS.items():
        if col not in existing_cols:
            conn.execute(f"ALTER TABLE entities ADD COLUMN {col} {ctype}")
    conn.execute("""CREATE TABLE IF NOT EXISTS relates (
        id INTEGER PRIMARY KEY,
        source_id INTEGER NOT NULL,
        target_id INTEGER NOT NULL,
        direction TEXT DEFAULT 'bidirectional',
        description TEXT,
        created_at TEXT,
        UNIQUE(source_id, target_id)
    )""")
    rel_cols = {r[1] for r in conn.execute("PRAGMA table_info(relates)").fetchall()}
    if "direction" not in rel_cols:
        try:
            conn.execute("ALTER TABLE relates ADD COLUMN direction TEXT DEFAULT 'bidirectional'")
        except Exception as e:
            _log.debug("relates.direction already exists: %s", e)
    if "description" not in rel_cols:
        try:
            conn.execute("ALTER TABLE relates ADD COLUMN description TEXT")
        except Exception as e:
            _log.debug("relates.description already exists: %s", e)
    conn.commit()


def get_db():
    """Get database connection with auto-migration."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("""CREATE TABLE IF NOT EXISTS entities (
        id INTEGER PRIMARY KEY, filepath TEXT UNIQUE, filename TEXT,
        phase TEXT DEFAULT 'preindividual', metadata JSON,
        body_preview TEXT, file_hash TEXT, updated_at TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS transitions (
        id INTEGER PRIMARY KEY, entity_id INTEGER, from_phase TEXT,
        to_phase TEXT, timestamp TEXT, reason TEXT)""")
    try:
        conn.execute("CREATE VIRTUAL TABLE IF NOT EXISTS entities_fts USING fts5(filename, body_preview, metadata_text)")
    except Exception as e:
        _log.debug("FTS5 table exists or unavailable: %s", e)
    _migrate_db(conn)
    return conn


# --- Utilities ---

def fhash(filepath):
    return hashlib.md5(Path(filepath).read_bytes()).hexdigest()[:12]


def self_check(op="write", meta=None):
    """Schema violation check."""
    violations = []
    allowed = {
        "id", "filepath", "filename", "phase", "metadata", "body_preview",
        "file_hash", "updated_at", "created_at", "parent_id", "urgency",
        "concepts", "deadline_date",
    }
    try:
        conn = get_db()
        cols = {r[1] for r in conn.execute("PRAGMA table_info(entities)").fetchall()}
        extra = cols - allowed
        if extra:
            violations.append(f"SCHEMA_VIOLATION: extra columns {extra}")
        conn.close()
    except Exception as e:
        _log.warning("self_check DB access failed: %s", e)
    if violations:
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        with open(LOGS_DIR / f"self_check_{datetime.now():%Y%m%d}.log", "a") as f:
            for v in violations:
                f.write(f"[{datetime.now().isoformat()}] {op}: {v}\n")
        for v in violations:
            print(f"  [VIOLATION] {v}")
    return violations


def extract_concepts(text):
    tl = text.lower()
    return [c for c, kws in CONCEPT_KW.items() if any(k in tl for k in kws)]


def detect_urgency(text):
    """Urgency is not inferred from keywords. Set explicitly."""
    return None


def _detect_tension(text):
    """Detect tension (disparation) in text."""
    tl = text.lower()
    oppositions = [
        (["fast", "urgent", "asap", "rush", "now"], ["slow", "later", "leisure", "someday", "long-term"]),
        (["build", "make", "implement", "develop"], ["buy", "purchase", "outsource", "service"]),
        (["simple", "minimal", "lean"], ["complex", "perfect", "elaborate"]),
        (["solo", "alone"], ["collaborate", "team", "together"]),
    ]
    dim_labels = [
        ("urgency_high", "urgency_low"),
        ("build", "buy"),
        ("simplicity", "complexity"),
        ("solo", "collaboration"),
    ]
    for (kws_a, kws_b), (label_a, label_b) in zip(oppositions, dim_labels):
        has_a = any(k in tl for k in kws_a)
        has_b = any(k in tl for k in kws_b)
        if has_a and has_b:
            return True, label_a, label_b
    return False, "", ""


def _find_deadline_file():
    """Find deadline file. Returns None if not found."""
    candidates = [
        DATA_DIR / "data" / "notion_dump" / "T9_deadlines.txt",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


# --- DB upsert ---

def _upsert(conn, rel, fname, phase, meta_json, preview, h, full_body="",
            created_at=None, parent_id=None, urgency=None, concepts=None):
    now = datetime.now().isoformat()
    row = conn.execute("SELECT id, file_hash FROM entities WHERE filepath=?", (rel,)).fetchone()
    if row and row["file_hash"] == h:
        return False

    concepts_str = json.dumps(concepts, ensure_ascii=False) if concepts else None

    if row:
        conn.execute(
            """UPDATE entities SET phase=?,metadata=?,body_preview=?,file_hash=?,
            updated_at=?,filename=?,urgency=?,concepts=? WHERE filepath=?""",
            (phase, meta_json, preview, h, now, fname, urgency, concepts_str, rel)
        )
        eid = row["id"]
    else:
        conn.execute(
            """INSERT INTO entities (filepath,filename,phase,metadata,body_preview,
            file_hash,updated_at,created_at,parent_id,urgency,concepts) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (rel, fname, phase, meta_json, preview, h, now,
             created_at or now, parent_id, urgency, concepts_str)
        )
        eid = conn.execute("SELECT id FROM entities WHERE filepath=?", (rel,)).fetchone()["id"]
    try:
        conn.execute("DELETE FROM entities_fts WHERE rowid=?", (eid,))
        conn.execute(
            "INSERT INTO entities_fts(rowid,filename,body_preview,metadata_text) VALUES(?,?,?,?)",
            (eid, fname, full_body or preview, meta_json)
        )
    except Exception as e:
        _log.debug("FTS upsert failed for %s: %s", fname, e)
    return True


def _build_entity_payload(filepath, meta, body):
    """Build entity payload from file."""
    concepts = extract_concepts(body) if body else []
    urgency = detect_urgency(body) if body else None
    if not meta.get("concepts") and concepts:
        meta["concepts"] = concepts
    if not meta.get("urgency") and urgency:
        meta["urgency"] = urgency
    return {
        "fname": filepath.name,
        "phase": meta.get("phase", "preindividual"),
        "meta_json": json.dumps(meta, ensure_ascii=False),
        "preview": body[:_preview_len(filepath, body)],
        "h": fhash(filepath),
        "full_body": body,
        "urgency": urgency,
        "concepts": concepts,
        "parent_id": meta.get("parent_id"),
    }


def _index_file(filepath):
    conn = get_db()
    try:
        rel = str(filepath.relative_to(DATA_DIR))
    except ValueError:
        rel = filepath.name
    meta, body = parse_file(filepath)
    p = _build_entity_payload(filepath, meta, body)
    _upsert(
        conn, rel, p["fname"], p["phase"], p["meta_json"], p["preview"], p["h"],
        full_body=p["full_body"], urgency=p["urgency"],
        concepts=p["concepts"], parent_id=p["parent_id"]
    )
    conn.commit()
    conn.close()


# --- Commands ---

def cmd_capture(text):
    """Save preindividual. Records disparation metadata when tension is detected."""
    now = datetime.now()
    title = re.sub(r'[^\w\s]', '', text[:30]).strip() or f"tension_{now:%H%M%S}"
    filepath = FIELD / f"{now:%Y%m%d}_{title}_{now:%H%M%S}.md"
    FIELD.mkdir(parents=True, exist_ok=True)
    concepts, urgency = extract_concepts(text), detect_urgency(text)

    meta = {
        "phase": "preindividual",
        "created": f"{now:%Y-%m-%d %H:%M}",
        "concepts": concepts,
        "urgency": urgency,
    }

    has_tension, dim_a, dim_b = _detect_tension(text)
    if has_tension:
        meta["disparation"] = {
            "dimension_a": dim_a,
            "dimension_b": dim_b,
            "resolution": "",
        }
        meta["phase"] = "tension_detected"
        print(f"  [!] Tension detected: {dim_a} vs {dim_b}")

    write_md(filepath, meta, text)
    self_check("capture", meta)
    print(f"  Saved: {filepath.name}")
    if concepts:
        print(f"  Concepts: {', '.join(concepts)}")

    try:
        conn = get_db()
        transductions = find_transductions(conn, concepts, text)
        report = format_transduction_report(transductions)
        if report:
            print(report)
    except Exception as e:
        print(f"  [warn] transduction detection failed: {e}", file=sys.stderr)

    _index_file(filepath)


def cmd_reindex(incremental=False):
    conn = get_db()
    existing = {
        r["filepath"]: r["file_hash"]
        for r in conn.execute("SELECT filepath, file_hash FROM entities").fetchall()
    }
    found, count, skipped = set(), 0, 0
    sources = [(sd, True, SCAN_EXTS) for sd in SCAN_DIRS] + [(DATA_DIR, False, SCAN_EXTS)]

    for src, recurse, exts in sources:
        if not src.exists():
            continue
        files = []
        for ext in exts:
            files.extend(src.rglob(f"*{ext}") if recurse else src.glob(f"*{ext}"))
        SKIP_DIRS = {'node_modules', '.next', '__pycache__', '.git', 'venv', '.venv', 'dist', 'build'}
        for f in files:
            if f.name.startswith("."):
                continue
            if any(skip in f.parts for skip in SKIP_DIRS):
                continue
            try:
                rel = str(f.relative_to(DATA_DIR))
            except ValueError:
                rel = f.name
            found.add(rel)
            try:
                if incremental and rel in existing:
                    current_hash = fhash(f)
                    if current_hash == existing[rel]:
                        skipped += 1
                        continue
                meta, body = parse_file(f)
                p = _build_entity_payload(f, meta, body)
                if _upsert(
                    conn, rel, p["fname"], p["phase"], p["meta_json"], p["preview"], p["h"],
                    full_body=p["full_body"], urgency=p["urgency"],
                    concepts=p["concepts"], parent_id=p["parent_id"]
                ):
                    count += 1
            except (OSError, sqlite3.Error, ValueError, json.JSONDecodeError) as e:
                _log.warning("reindex skip %s: %s", f.name, e)
                continue
    PROTECTED_PREFIXES = ("_legacy/", "memory/memory_")
    for d in set(existing.keys()) - found:
        if any(d.startswith(p) for p in PROTECTED_PREFIXES):
            continue
        conn.execute("DELETE FROM entities WHERE filepath=?", (d,))
        count += 1
    conn.commit()
    conn.close()
    self_check("reindex")
    print(f"  Scanned: {len(found)} items, updated: {count} items")


def cmd_search(query):
    conn = get_db()
    results = conn.execute(
        "SELECT id,filename,phase,metadata,urgency,concepts FROM entities "
        "WHERE filename LIKE ? OR body_preview LIKE ? OR concepts LIKE ? OR metadata LIKE ? "
        "ORDER BY "
        "  CASE WHEN filename LIKE ? THEN 0 ELSE 1 END, "
        "  CASE WHEN phase='stabilized' THEN 0 WHEN phase='tension_detected' THEN 1 ELSE 2 END, "
        "  id DESC "
        "LIMIT 40",
        (f"%{query}%",) * 4 + (f"%{query}%",)
    ).fetchall()
    if not results:
        print("  No results found")
    else:
        for r in results:
            tags = r["concepts"] or ""
            if tags:
                try:
                    tags = ", ".join(json.loads(tags))
                except Exception:
                    pass
            else:
                m = json.loads(r["metadata"]) if r["metadata"] else {}
                tags = m.get("concepts", m.get("tags", ""))
                if isinstance(tags, list):
                    tags = ", ".join(str(t) for t in tags)
            urg = r["urgency"] or ""
            urg_mark = f" [{urg}]" if urg and urg != "mid" else ""
            print(f"  [{r['id']:3d}] {r['phase'][:12]:12s} | {r['filename'][:50]:50s} | {tags}{urg_mark}")
    conn.close()


def cmd_status():
    conn = get_db()
    phases = conn.execute(
        "SELECT phase, COUNT(*) as cnt FROM entities GROUP BY phase ORDER BY cnt DESC"
    ).fetchall()
    total = sum(r["cnt"] for r in phases)
    print(f"\n  === T9 OS Seed v0.3 (total {total} items) ===\n")
    for r in phases:
        print(f"  {r['phase']:20s} {r['cnt']:4d}  {'#' * min(r['cnt'], 30)}")
    rel_count = conn.execute("SELECT COUNT(*) as c FROM relates").fetchone()["c"]
    if rel_count:
        print(f"\n  Relations (transduction): {rel_count} items")
    conn.close()


def _is_movable(filepath_rel):
    """Check if file is movable."""
    movable_roots = set()
    for rel_path in PHASE_DIR_KEYS.values():
        movable_roots.add(rel_path.split("/")[0])
    first_part = Path(filepath_rel).parts[0] if Path(filepath_rel).parts else ""
    return first_part in movable_roots


def cmd_transition(eid, to_phase, reason=""):
    conn = get_db()
    row = conn.execute("SELECT * FROM entities WHERE id=?", (eid,)).fetchone()
    if not row:
        print(f"  ID {eid} not found")
        conn.close()
        return
    fp = row["phase"]
    if to_phase not in TRANSITIONS.get(fp, set()):
        print(f"  Transition not allowed: {fp} -> {to_phase}  Allowed: {', '.join(TRANSITIONS.get(fp, set()))}")
        conn.close()
        return
    old_path = DATA_DIR / row["filepath"]
    is_protected = not _is_movable(row["filepath"])

    if is_protected:
        meta = json.loads(row["metadata"]) if row["metadata"] else {}
        meta["phase"] = to_phase
        meta["transitioned_at"] = f"{datetime.now():%Y-%m-%d %H:%M}"
        if old_path.suffix == ".md" and old_path.exists():
            _, body = parse_md(old_path)
            write_md(old_path, meta, body)
        new_rel = row["filepath"]
    elif old_path.suffix == ".md":
        meta, body = parse_md(old_path)
        meta["phase"] = to_phase
        meta["transitioned_at"] = f"{datetime.now():%Y-%m-%d %H:%M}"
        new_dir = PHASE_DIR.get(to_phase, FIELD)
        new_dir.mkdir(parents=True, exist_ok=True)
        new_path = new_dir / old_path.name
        self_check("transition", meta)
        write_md(new_path, meta, body)
        if old_path != new_path and old_path.exists():
            old_path.unlink()
        new_rel = str(new_path.relative_to(DATA_DIR))
    else:
        meta = json.loads(row["metadata"]) if row["metadata"] else {}
        meta["phase"] = to_phase
        meta["transitioned_at"] = f"{datetime.now():%Y-%m-%d %H:%M}"
        new_dir = PHASE_DIR.get(to_phase, FIELD)
        new_dir.mkdir(parents=True, exist_ok=True)
        new_path = new_dir / old_path.name
        if old_path != new_path and old_path.exists():
            try:
                shutil.move(str(old_path), str(new_path))
            except PermissionError:
                shutil.copy2(str(old_path), str(new_path))
                try:
                    old_path.unlink()
                except PermissionError:
                    pass
        new_rel = str(new_path.relative_to(DATA_DIR))

    conn.execute(
        "UPDATE entities SET phase=?,filepath=?,updated_at=?,metadata=? WHERE id=?",
        (to_phase, new_rel, datetime.now().isoformat(), json.dumps(meta, ensure_ascii=False), eid)
    )
    conn.execute(
        "INSERT INTO transitions (entity_id,from_phase,to_phase,timestamp,reason) VALUES(?,?,?,?,?)",
        (eid, fp, to_phase, datetime.now().isoformat(), reason)
    )
    conn.commit()
    conn.close()
    print(f"  {fp} -> {to_phase}: {old_path.name}")


def cmd_tidy():
    _cmd_tidy(get_db, cmd_transition)


def cmd_daily():
    _cmd_daily(get_db, _find_deadline_file)


def cmd_compose(text):
    _cmd_compose(text, extract_concepts, detect_urgency, _detect_tension)


def cmd_approve(cid, choice):
    _cmd_approve(cid, choice, self_check, write_md, _index_file)


def cmd_reflect():
    _cmd_reflect(get_db)


def cmd_consolidate():
    _cmd_consolidate(get_db, fhash, _upsert, _preview_len)


def cmd_watch(interval=5):
    _cmd_watch(get_db, fhash, cmd_reindex, interval)


def cmd_history(eid):
    _cmd_history(get_db, eid)


def cmd_relate(id1, id2, direction="bidirectional", description=""):
    _cmd_relate(get_db, self_check, id1, id2, direction, description)


def cmd_digest_index():
    _cmd_digest_index(get_db, fhash, _upsert, _preview_len)


def cmd_legacy(query):
    _cmd_legacy(query)


def cmd_ingest(filepath):
    _cmd_ingest(cmd_capture, filepath)


def cmd_resurface(keyword=""):
    _cmd_resurface(get_db, keyword)


def cmd_rebuild_fts():
    _cmd_rebuild_fts(get_db)


def cmd_orphans():
    _cmd_orphans(get_db)


def cmd_deadlines(show_all=False):
    """Deadline view -- filter entities with deadline_date only."""
    conn = get_db()
    today = datetime.now().strftime("%Y-%m-%d")
    if show_all:
        rows = conn.execute(
            "SELECT id, filename, deadline_date, urgency, phase FROM entities "
            "WHERE deadline_date IS NOT NULL AND phase NOT IN ('dissolved','sediment') "
            "ORDER BY deadline_date"
        ).fetchall()
    else:
        cutoff = (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d")
        rows = conn.execute(
            "SELECT id, filename, deadline_date, urgency, phase FROM entities "
            "WHERE deadline_date IS NOT NULL AND deadline_date >= ? AND deadline_date <= ? "
            "AND phase NOT IN ('dissolved','sediment') "
            "ORDER BY deadline_date",
            (today, cutoff)
        ).fetchall()
    conn.close()
    if not rows:
        print("  No deadlines")
        return
    print(f"\n  === Deadlines ({len(rows)} items) ===\n")
    for r in rows:
        delta = (datetime.strptime(r["deadline_date"], "%Y-%m-%d").date() - datetime.now().date()).days
        if delta < 0:
            label = "Past"
        elif delta == 0:
            label = "Today"
        elif delta == 1:
            label = "Tmrw"
        else:
            label = f"D-{delta}"
        name = r["filename"].replace(".md", "")
        name = re.sub(r'^\d{8}_?', '', name)
        name = re.sub(r'^deadline_', '', name)
        name = re.sub(r'_?\d{6}$', '', name)
        name = re.sub(r'\s*\d{8,}', '', name)
        name = name.replace("_", " ").strip()[:40]
        urg = " *URGENT*" if r["urgency"] == "high" else ""
        print(f"    {label:6s} {r['deadline_date']} {name}{urg}")
